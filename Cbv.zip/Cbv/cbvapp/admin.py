from django.contrib import admin
from cbvapp.models import company,product

# Register your models here.
admin.site.register(company)
admin.site.register(product)