from django.shortcuts import render
from django.views.generic import View,TemplateView
from django.http import HttpResponse

# Create your views here.
class htmlview(TemplateView):
    template_name = 'index.html'

# class myclassview(view):
#     def get(self, request):
#         return HttpResponse("<h1> hello welcome to the cbv </h1> ")
    
         