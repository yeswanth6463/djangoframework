from django.contrib import admin
from DefectsPortal.models import Defect, Defects_screen_shots


# Register your models here.
class DefectlistAdmin(admin.ModelAdmin):
    list_display =['defect_name','assigned_to','defects_status']

admin.site.register(Defect)
admin.site.register(Defects_screen_shots)
