from django.apps import AppConfig


class DefectsportalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DefectsPortal'
