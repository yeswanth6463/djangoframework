from django.contrib import admin
from DefectsPortal.models import Defect, Defects_screen_shots


# Register your models here.

admin.site.register(Defect)
admin.site.register(Defects_screen_shots)
